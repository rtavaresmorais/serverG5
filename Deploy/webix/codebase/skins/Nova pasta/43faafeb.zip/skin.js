//[Skin Customization]
webix.skin.flat.barHeight=35;webix.skin.flat.tabbarHeight=45;webix.skin.flat.rowHeight=44;webix.skin.flat.listItemHeight=34;webix.skin.flat.inputHeight=45;webix.skin.flat.layoutMargin.wide=1;webix.skin.flat.layoutMargin.space=1;webix.skin.flat.layoutPadding.space=5;
 webix.skin.set('flat');