
Skin for Webix UI ( http://webix.com )
=======================================

To preview or adjust skin visit
	https://webix.com/skin-builder/43faafeb

#### How to use

- Replace the existing webix.css with the one from the package
- As for the js file, you can replace the existing webix.js with the one included into the package or preserve the existing js file and just add the skin.js on your web page (the second approach is useful if you either use CDN version of webix.js or Webix Pro )

#### How to update to a new version of Webix

When a new version is released, just visit 
	https://webix.com/skin-builder/43faafeb
and re-download the package. Thus, you’ll get the updated version of the library with the same skin settings.

